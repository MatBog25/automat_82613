import tkinter as tk

ilosc_liter = int(input("Podaj dlugosc swojego slowa: "))
win = tk.Tk()
win.title("Automat deterministyczny")

canvas = tk.Canvas(win, width=1100, height=600)
canvas.pack(side="left")

# Stany
kolor = ["#007328", "#00db4d"]
c1 = canvas.create_oval(50, 150, 150, 250, fill=kolor[0], outline="black")
c2 = canvas.create_oval(350, 150, 450, 250, fill=kolor[0], outline="black", width=1.5)
c3 = canvas.create_oval(650, 150, 750, 250, fill=kolor[0], outline="black", width=1.5)
canvas.create_oval(942, 142, 1058, 258, fill="#e6e6e6", outline="black", width=1.5)
c4 = canvas.create_oval(950, 150, 1050, 250, fill=kolor[0], outline="black", width=1.5)

# Strzalki
canvas.create_line(200, 200, 300, 200, arrow=tk.LAST, arrowshape="10 20 10")
canvas.create_line(500, 200, 600, 200, arrow=tk.LAST, arrowshape="10 20 10")
canvas.create_line(800, 200, 900, 200, arrow=tk.LAST, arrowshape="10 20 10")

state1 = tk.Label(win, text="Q0", font=("Arial", 20), bg='#007328')
state2 = tk.Label(win, text="Q1", font=("Arial", 20), bg='#007328')
state3 = tk.Label(win, text="Q3", font=("Arial", 20), bg='#007328')
state4 = tk.Label(win, text="Q4", font=("Arial", 20), bg='#007328')
twoje_slowo = tk.Label(win, text="Twoje słowo:", font=("Arial", 20))

canvas.create_window(100, 200, window=state1, anchor="center")
canvas.create_window(400, 200, window=state2, anchor="center")
canvas.create_window(700, 200, window=state3, anchor="center")
canvas.create_window(1000, 200, window=state4, anchor="center")
canvas.create_window(550, 50, window=twoje_slowo, anchor="center")
label_bg = state1
current_state = c1
czas = 0

def main():
    global current_state
    if not 'current_state' in globals():
        current_state = c1
    global slowo
    if not 'slowo' in globals():
        slowo = ''
    global label_bg
    if not 'label_bg' in globals():
        label_bg = state1
    global ilosc_liter
    if not 'ilosc_liter' in globals():
        ilosc_liter = 3
    global symbol
    if not 'symbol' in globals():
        symbol = ''
    global czas
    if not 'czas' in globals():
        czas = 0

    symbol = input("Wprowadź symbol: ")
    slowo = slowo + symbol
    czas += 1
    label5 = tk.Label(win, text=slowo, font=("Arial", 20))
    canvas.create_window(550, 100, window=label5, anchor="center")

    if symbol == "a":
        canvas.itemconfig(current_state, fill="#007328")
        label_bg.config(bg="#007328")
        if current_state == c1:
            current_state = c2
            label_bg = state2
        elif current_state == c2:
            current_state = c3
            label_bg = state3
        elif current_state == c3:
            current_state = c4
            label_bg = state4
        canvas.itemconfig(current_state, fill="#00db4d")
        label_bg.config(bg="#00db4d")
        win.after(500, main)
    elif symbol == 'b':
        if current_state == c1:
            current_state = c1
            label_bg = state1
        elif current_state == c2:
            canvas.itemconfig(current_state, fill="#007328")
            label_bg.config(bg="#007328")
            current_state = c1
            label_bg = state1
            label_bg.config(bg="#00db4d")
            canvas.itemconfig(current_state, fill="#00db4d")
        elif current_state == c3:
            canvas.itemconfig(current_state, fill="#007328")
            label_bg.config(bg="#007328")
            current_state = c1
            label_bg = state1
            label_bg.config(bg="#00db4d")
            canvas.itemconfig(current_state, fill="#00db4d")
        win.after(500, main)
    else:
        exit('Znak nie nalezy do alfabetu AB')

    if ilosc_liter == len(slowo):
        if current_state == c4 and slowo[-3:] == "aaa":
            print("Słowo zostało zaakceptowane!")
            exit()
        else:
            print("Słowo nie zostało zaakceptowane!")
            exit()

win.after(700, main)
win.mainloop()
